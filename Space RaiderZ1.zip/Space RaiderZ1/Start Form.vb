﻿Public Class Start_Form

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        Menu_Form.Show() 'shows the main menu
    End Sub
End Class