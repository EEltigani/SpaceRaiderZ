﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_Space_Attack
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form_Space_Attack))
        Me.picshooter1 = New System.Windows.Forms.PictureBox()
        Me.picalien5 = New System.Windows.Forms.PictureBox()
        Me.picalien1 = New System.Windows.Forms.PictureBox()
        Me.picalien2 = New System.Windows.Forms.PictureBox()
        Me.picalien9 = New System.Windows.Forms.PictureBox()
        Me.picalien8 = New System.Windows.Forms.PictureBox()
        Me.picalien3 = New System.Windows.Forms.PictureBox()
        Me.picalien4 = New System.Windows.Forms.PictureBox()
        Me.picalien7 = New System.Windows.Forms.PictureBox()
        Me.picalien6 = New System.Windows.Forms.PictureBox()
        Me.picbullet1 = New System.Windows.Forms.PictureBox()
        Me.TimerGaming = New System.Windows.Forms.Timer(Me.components)
        Me.picalien10 = New System.Windows.Forms.PictureBox()
        Me.lblscore1 = New System.Windows.Forms.Label()
        Me.lbllevel1 = New System.Windows.Forms.Label()
        CType(Me.picshooter1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picbullet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picalien10, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picshooter1
        '
        Me.picshooter1.BackColor = System.Drawing.Color.Transparent
        Me.picshooter1.BackgroundImage = CType(resources.GetObject("picshooter1.BackgroundImage"), System.Drawing.Image)
        Me.picshooter1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picshooter1.Location = New System.Drawing.Point(430, 483)
        Me.picshooter1.Name = "picshooter1"
        Me.picshooter1.Size = New System.Drawing.Size(80, 71)
        Me.picshooter1.TabIndex = 0
        Me.picshooter1.TabStop = False
        '
        'picalien5
        '
        Me.picalien5.BackgroundImage = CType(resources.GetObject("picalien5.BackgroundImage"), System.Drawing.Image)
        Me.picalien5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien5.Location = New System.Drawing.Point(265, 7)
        Me.picalien5.Name = "picalien5"
        Me.picalien5.Size = New System.Drawing.Size(50, 50)
        Me.picalien5.TabIndex = 1
        Me.picalien5.TabStop = False
        '
        'picalien1
        '
        Me.picalien1.BackColor = System.Drawing.Color.Transparent
        Me.picalien1.BackgroundImage = CType(resources.GetObject("picalien1.BackgroundImage"), System.Drawing.Image)
        Me.picalien1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien1.Location = New System.Drawing.Point(0, 7)
        Me.picalien1.Name = "picalien1"
        Me.picalien1.Size = New System.Drawing.Size(50, 50)
        Me.picalien1.TabIndex = 2
        Me.picalien1.TabStop = False
        '
        'picalien2
        '
        Me.picalien2.BackgroundImage = CType(resources.GetObject("picalien2.BackgroundImage"), System.Drawing.Image)
        Me.picalien2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien2.Location = New System.Drawing.Point(66, 7)
        Me.picalien2.Name = "picalien2"
        Me.picalien2.Size = New System.Drawing.Size(50, 50)
        Me.picalien2.TabIndex = 3
        Me.picalien2.TabStop = False
        '
        'picalien9
        '
        Me.picalien9.BackgroundImage = CType(resources.GetObject("picalien9.BackgroundImage"), System.Drawing.Image)
        Me.picalien9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien9.Location = New System.Drawing.Point(516, 7)
        Me.picalien9.Name = "picalien9"
        Me.picalien9.Size = New System.Drawing.Size(50, 50)
        Me.picalien9.TabIndex = 4
        Me.picalien9.TabStop = False
        '
        'picalien8
        '
        Me.picalien8.BackgroundImage = CType(resources.GetObject("picalien8.BackgroundImage"), System.Drawing.Image)
        Me.picalien8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien8.Location = New System.Drawing.Point(460, 7)
        Me.picalien8.Name = "picalien8"
        Me.picalien8.Size = New System.Drawing.Size(50, 50)
        Me.picalien8.TabIndex = 5
        Me.picalien8.TabStop = False
        '
        'picalien3
        '
        Me.picalien3.BackgroundImage = CType(resources.GetObject("picalien3.BackgroundImage"), System.Drawing.Image)
        Me.picalien3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien3.Location = New System.Drawing.Point(131, 7)
        Me.picalien3.Name = "picalien3"
        Me.picalien3.Size = New System.Drawing.Size(50, 50)
        Me.picalien3.TabIndex = 6
        Me.picalien3.TabStop = False
        '
        'picalien4
        '
        Me.picalien4.BackgroundImage = CType(resources.GetObject("picalien4.BackgroundImage"), System.Drawing.Image)
        Me.picalien4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien4.Location = New System.Drawing.Point(199, 7)
        Me.picalien4.Name = "picalien4"
        Me.picalien4.Size = New System.Drawing.Size(50, 50)
        Me.picalien4.TabIndex = 7
        Me.picalien4.TabStop = False
        '
        'picalien7
        '
        Me.picalien7.BackgroundImage = CType(resources.GetObject("picalien7.BackgroundImage"), System.Drawing.Image)
        Me.picalien7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien7.Location = New System.Drawing.Point(397, 7)
        Me.picalien7.Name = "picalien7"
        Me.picalien7.Size = New System.Drawing.Size(50, 50)
        Me.picalien7.TabIndex = 8
        Me.picalien7.TabStop = False
        '
        'picalien6
        '
        Me.picalien6.BackgroundImage = CType(resources.GetObject("picalien6.BackgroundImage"), System.Drawing.Image)
        Me.picalien6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien6.Location = New System.Drawing.Point(331, 7)
        Me.picalien6.Name = "picalien6"
        Me.picalien6.Size = New System.Drawing.Size(50, 50)
        Me.picalien6.TabIndex = 9
        Me.picalien6.TabStop = False
        '
        'picbullet1
        '
        Me.picbullet1.BackgroundImage = CType(resources.GetObject("picbullet1.BackgroundImage"), System.Drawing.Image)
        Me.picbullet1.Location = New System.Drawing.Point(465, 416)
        Me.picbullet1.Name = "picbullet1"
        Me.picbullet1.Size = New System.Drawing.Size(10, 21)
        Me.picbullet1.TabIndex = 10
        Me.picbullet1.TabStop = False
        '
        'TimerGaming
        '
        Me.TimerGaming.Enabled = True
        Me.TimerGaming.Interval = 35
        '
        'picalien10
        '
        Me.picalien10.BackgroundImage = CType(resources.GetObject("picalien10.BackgroundImage"), System.Drawing.Image)
        Me.picalien10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.picalien10.Location = New System.Drawing.Point(572, 7)
        Me.picalien10.Name = "picalien10"
        Me.picalien10.Size = New System.Drawing.Size(50, 50)
        Me.picalien10.TabIndex = 11
        Me.picalien10.TabStop = False
        '
        'lblscore1
        '
        Me.lblscore1.AutoSize = True
        Me.lblscore1.Location = New System.Drawing.Point(834, 505)
        Me.lblscore1.Name = "lblscore1"
        Me.lblscore1.Size = New System.Drawing.Size(33, 13)
        Me.lblscore1.TabIndex = 12
        Me.lblscore1.Text = "score"
        '
        'lbllevel1
        '
        Me.lbllevel1.AutoSize = True
        Me.lbllevel1.Location = New System.Drawing.Point(828, 462)
        Me.lbllevel1.Name = "lbllevel1"
        Me.lbllevel1.Size = New System.Drawing.Size(29, 13)
        Me.lbllevel1.TabIndex = 13
        Me.lbllevel1.Text = "level"
        '
        'Form_Space_Attack
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(949, 581)
        Me.Controls.Add(Me.lbllevel1)
        Me.Controls.Add(Me.lblscore1)
        Me.Controls.Add(Me.picalien10)
        Me.Controls.Add(Me.picbullet1)
        Me.Controls.Add(Me.picalien6)
        Me.Controls.Add(Me.picalien7)
        Me.Controls.Add(Me.picalien4)
        Me.Controls.Add(Me.picalien3)
        Me.Controls.Add(Me.picalien8)
        Me.Controls.Add(Me.picalien9)
        Me.Controls.Add(Me.picalien2)
        Me.Controls.Add(Me.picalien1)
        Me.Controls.Add(Me.picalien5)
        Me.Controls.Add(Me.picshooter1)
        Me.Name = "Form_Space_Attack"
        Me.Text = "Form_Space_Attack"
        CType(Me.picshooter1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picbullet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picalien10, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picshooter1 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien5 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien1 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien2 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien9 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien8 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien3 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien4 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien7 As System.Windows.Forms.PictureBox
    Friend WithEvents picalien6 As System.Windows.Forms.PictureBox
    Friend WithEvents picbullet1 As System.Windows.Forms.PictureBox
    Friend WithEvents TimerGaming As System.Windows.Forms.Timer
    Friend WithEvents picalien10 As System.Windows.Forms.PictureBox
    Friend WithEvents lblscore1 As System.Windows.Forms.Label
    Friend WithEvents lbllevel1 As System.Windows.Forms.Label
End Class
